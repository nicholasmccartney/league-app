const express = require("express");
const axios = require("axios");
const cors = require("cors");

var riot_api_token = "RGAPI-3bfc6d31-2933-4dce-8df7-0e46214d8d82";

const instance = axios.create({
  baseURL: "https://na1.api.riotgames.com",
  headers: {
    "X-Riot-Token": process.env.RIOT_API_TOKEN,
  },
});

const app = express();
app.use(cors());

app.get("/summoner/:summoner", (req, res) => {
  var url = `/lol/summoner/v4/summoners/by-name/${req.params.summoner}`;
  instance
    .get(url)
    .then(function (response) {
      res.json(response.data);
    })
    .catch(function (error) {
      console.log(error);
    });
});

const PORT = process.env.PORT || 80;
app.listen(PORT, () => console.log(`listening on ${PORT}`));
